//volver al inicio
// logo.addEventListener('click', () =>{
//     location.hash='';
//     window.history.replaceState({},document.title,"/main.html");
// })
//abrir notificaciones
// notifsBtn.addEventListener('click',()=>{
//     notifsContainer.classList.toggle('cm-u-inactive')
//     notifsBtn.classList.toggle('active');
// });


